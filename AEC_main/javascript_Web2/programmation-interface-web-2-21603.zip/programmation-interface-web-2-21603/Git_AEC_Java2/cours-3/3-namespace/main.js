(function(MEN) {

    /**
     * Récupère les objets stockés dans l'objet MON_ESPACE_NOM (MEN)
     */

    console.log(MEN);





    /*
    * Instances de Personne
    */


        


    /*
    * Instances de Etudiant
    */





    /*
    * Instances de Professeur
    */





})(MON_ESPACE_NOM);