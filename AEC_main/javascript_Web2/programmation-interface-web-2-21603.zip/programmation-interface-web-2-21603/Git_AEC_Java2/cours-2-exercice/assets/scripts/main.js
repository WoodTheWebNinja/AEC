/**
 * Lance les instances de chaque calculatrice :
 *      - passer la référence au noeud DOM courant en argument lors de l’instantiation de l’objet Calculatrice
 *      - appeler la méthode init() de l'objet Calculatrice lors de l'instanciation
 */



window.addEventListener("DOMContentLoaded", function(){


    let elCalculatrice = document.querySelectorAll("[data-js-calculatrice]");

    for (let i = 0, l = elCalculatrice.length ; i < l; i++) {
    
        new Calculatrice(elCalculatrice(i)).init() ; 

    }



}); 
