(function(VEHICULE) {

    /* Objets */
    let Neuve = VEHICULE.Neuve,
        Occasion = VEHICULE.Occasion;

    /* Véhicules */
    // neuves    : marque, modele, annee, image, prix, rabais, [couleurs]
    // occasions : marque, modele, annee, image, prix, rabais, couleur, nbKm, transmission

    let neuves = [
        ['Nissan', 'Leaf Plus SV', '2022', './assets/img/neuves/neuve-1.jpeg', 52329, 500, ['darkred', 'Grey', '#000000']],
        ['Kia', 'Rio LX+', '2022', './assets/img/neuves/neuve-2.jpeg', 20220, null, ['#000000', 'darkblue']],
        ['Dodge', 'Challenger', '2021', './assets/img/neuves/neuve-3.jpeg', 52265, 500, ['#232323', '#ff8c00', 'darkblue']],
    ];
    let occasions = [
        ['Kya', 'Forte', '2015', './assets/img/occasions/occasion-1.jpeg', 9298, 1000, '#161616', '116,252', 'Manuelle'],
        ['Nissan', 'Versa Note SV', '2018', './assets/img/occasions/occasion-2.jpeg', 12198, null, '#081326', '93,561', 'Automatique' ],
        ['Hyundai', 'Elantra', '2014', './assets/img/occasions/occasion-3.jpeg', 7898, null, '#8b0000', '93,991', 'Manuelle' ]
    ];





})(VEHICULE);