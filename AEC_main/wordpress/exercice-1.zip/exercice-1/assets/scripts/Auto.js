var VEHICULE = VEHICULE || {};

(function() {





 
})();