<?php

interface Age {
    public function calcAge();
}