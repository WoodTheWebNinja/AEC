<?php

abstract class Animal {
    protected $type = "cat" ;


    abstract public function setType($type);
    abstract public function getType();

    

}

?>