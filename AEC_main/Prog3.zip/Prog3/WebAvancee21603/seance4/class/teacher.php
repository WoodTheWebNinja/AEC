<?php

class teacher extends Person{
    private $teacherId;
    private $salarie;
    
    public function setCodePostal($code){
        $this->codePostal;
    }
    public function getCodePostal(){
        return $this->codePostal;
    }
}