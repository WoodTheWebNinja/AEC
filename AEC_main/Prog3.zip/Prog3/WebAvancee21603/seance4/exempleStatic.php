<?php
require 'class/person.php';
require 'class/student.php';

echo Student::setStudentId(1);

?>