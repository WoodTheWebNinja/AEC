<?php

interface Shape {
    public function calcArea();
}
