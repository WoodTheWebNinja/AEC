<?php
require "classRedirect.php";

//RedirectPage::redirect("http://www.google.com");

echo RedirectPage::$staticProp;