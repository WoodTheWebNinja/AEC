/**
 * Comportements de chaque calculatrice
 */

function aPlusB (valeur1,valeur2) { 
 
     let x = valeur1 ;
     let y = valeur2 ; 

     return x+y ; 


};


function aFoisB (valeur1,valeur2) { 
 
    let x = valeur1 ;
    let y = valeur2 ; 

    return x*y ; 


};

function aMoinsB (valeur1,valeur2) { 
 
    let x = valeur1 ;
    let y = valeur2 ; 

    return x-y ; 


};

function aDivisionB (valeur1,valeur2) { 
 
    let x = valeur1 ;
    let y = valeur2 ; 

    return x/y ; 


};








 let  W =  aDivisionB(10,5) ;

 console.log(W) ;