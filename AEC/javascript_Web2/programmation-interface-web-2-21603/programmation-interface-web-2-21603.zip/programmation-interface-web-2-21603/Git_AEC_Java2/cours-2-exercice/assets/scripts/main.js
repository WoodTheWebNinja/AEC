/**
 * Lance les instances de chaque calculatrice :
 *      - passer la référence au noeud DOM courant en argument lors de l’instantiation de l’objet Calculatrice
 *      - appeler la méthode init() de l'objet Calculatrice lors de l'instanciation
 */




