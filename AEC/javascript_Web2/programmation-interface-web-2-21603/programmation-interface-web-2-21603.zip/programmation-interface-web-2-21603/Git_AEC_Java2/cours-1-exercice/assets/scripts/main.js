/**
 * Vous avez 5 éléments DOM affichant un nombre,
 * au click d'un des deux boutons à sa gauche faites le calcul (plus ou moins un) de ce nombre.
 * Évidemment, vous aurez à travailler en orienté objet en utilisant la syntaxe des classes ES6.
 */

